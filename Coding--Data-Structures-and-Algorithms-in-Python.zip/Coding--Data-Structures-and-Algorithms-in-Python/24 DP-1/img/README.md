This folder contains all the images which are used in Dynamic Programming - 1. 

Source: GeeksForGeeks, Coding Ninjas and so on and so forth
