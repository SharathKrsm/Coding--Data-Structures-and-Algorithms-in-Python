This folder contains all the images used in this repo
